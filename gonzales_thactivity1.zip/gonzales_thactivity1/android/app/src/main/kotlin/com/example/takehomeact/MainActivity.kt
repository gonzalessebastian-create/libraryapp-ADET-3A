package com.example.takehomeact

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
