import 'package:flutter/material.dart';
import 'package:takehomeact/pages/zodiacfinder_screen.dart';

void main() {
  runApp(MyConst());
}

class MyConst extends StatelessWidget {
  const MyConst({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'constellation finder',
      theme: ThemeData(
        colorSchemeSeed: Colors.blue,
        useMaterial3: true 
      ),
      home: ZodicFinderPage(),

    );
  }
}