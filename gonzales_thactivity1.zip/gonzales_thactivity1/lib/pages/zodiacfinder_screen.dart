import 'package:flutter/material.dart';
import 'package:takehomeact/widgets/custom_text_field.dart';


class ZodicFinderPage extends StatefulWidget {
  const ZodicFinderPage({super.key});
  

  @override
  State<ZodicFinderPage> createState() => _ZodicFinderPageState();
}

class _ZodicFinderPageState extends State<ZodicFinderPage> {

  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _ageController = TextEditingController();
  final List<String> _months = [
    "January","February","March","April","May","June","July","August","September","October","November","December"
  ];

  String? _selectedMonth;
  String _errorMessage = "";

  void _clearData() {  //10th
  _nameController.clear();
  _ageController.clear();

  }


  void _showZodiacDialog() {
    if(_nameController.text.isEmpty || _ageController.text.isEmpty || _selectedMonth == null) {
      setState(() {
        _errorMessage = "Please Fill In all fields (name, age, And month)!";
      });
      return;
    }
    setState(() {
      _errorMessage = "";
    });

    String zodiac = "";
    String traits = "";

    switch (_selectedMonth) {
    case "January": zodiac = "Capricorn / Aquarius"; traits = "Ambitious & Independent"; break;
    case "February": zodiac = "Aquarius / Pisces"; traits = "Creative & Compassionate"; break;
    case "March": zodiac = "Pisces / Aries"; traits = "Imaginative & Courageous"; break;
    case "April": zodiac = "Aries / Taurus"; traits = "Determined & Reliable"; break;
    case "May": zodiac = "Taurus / Gemini"; traits = "Patient & Adaptable"; break;
    case "June": zodiac = "Gemini / Cancer"; traits = "Curious & Intuitive"; break;
    case "July": zodiac = "Cancer / Leo"; traits = "Protective & Charismatic"; break;
    case "August": zodiac = "Leo / Virgo"; traits = "Confident & Analytical"; break;
    case "September": zodiac = "Virgo / Libra"; traits = "Salsalero"; break;
    case "October": zodiac = "Libra / Scorpio"; traits = "Fair & Passionate"; break;
    case "November": zodiac = "Scorpio / Sagittarius"; traits = "Intense & Optimistic"; break;
    case "December": zodiac = "Sagittarius / Capricorn"; traits = "Adventurous & Disciplined";
    break;
    }

  showDialog(
  context: context, 
  builder: (context) {
    return AlertDialog(
      title: Text("Hello, ${_nameController.text}"),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Icon(Icons.auto_awesome, color: Colors.amber, size: 50),
          const Divider(),
          Text("Your Month: $_selectedMonth"),
          const SizedBox(height: 10),
          Text(
            "Zodiac: $zodiac",
            style: const TextStyle(fontSize: 18, color: Colors.purple, fontWeight: FontWeight.bold),
          ),
          Text("Traits: $traits",style: const TextStyle(fontStyle: FontStyle.italic)),
        ],
      ),
      actions: [
        TextButton(
        onPressed: () => Navigator.pop(context), 
        child: const Text("Awesome"))
      ],
    );
  }
  );
  }

  
  

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Center(
          child: Text(
            'Zodiac Finder',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
              color: Colors.white
            ),
          )
          ),
        backgroundColor: Theme.of(context).colorScheme.primary,
      ),
      body: Padding(
        padding: const EdgeInsets.all(10.0),
        child: Column(
          children: [
            CircleAvatar(
              radius: 40,
              backgroundImage: AssetImage('assets/images/light-yagami-writing-death-note-.jpg'),
            ),
            Text('What Is Your Zodiac?',
            style: TextStyle(
              fontWeight: FontWeight.bold,
              fontSize: 18,
            )
            ),
            Text('Discover Your Cosmic Personality!',
            style: TextStyle(
              fontWeight: FontWeight.normal,
              fontSize: 10
            )
            ),
            Divider(
              thickness: 2,
              color: Colors.grey,
            ),

            CustomTextField(
            controller: _nameController, 
            label: "Fullname", 
            icon: Icons.mail_outline_outlined, 
            textInputType: TextInputType.name
            ),

            CustomTextField(
            controller: _ageController, 
            label: "Age", 
            icon: Icons.mail_outline_outlined, 
            textInputType: TextInputType.number
            ),


            DropdownButtonFormField<String>(
                  hint: const Text("Select Birth Month"),
                  items: _months.map((month) {
                    return DropdownMenuItem<String>(
                      value: month,
                      child: Text(month),
                    );
                  }).toList(),
                  onChanged: (value) {
                    setState(() {
                      _selectedMonth = value;
                    });
                  },
                  decoration: InputDecoration(
                    labelText: "Birth Month",        // matches your CustomTextField label
                    prefixIcon: Icon(Icons.calendar_today), // optional icon like CustomTextField
                    border: OutlineInputBorder(),     // rectangular shape
                    contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 15),
                  ),
                ),


              if (_errorMessage.isNotEmpty)
                Padding(
                  padding: const EdgeInsetsGeometry.only(top: 8),
                  child: Text(
                    _errorMessage,
                    style: const TextStyle(
                      color: Colors.red,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  ),
              

              const SizedBox(height: 18),

              Row(
                children: [
                  Expanded(
                    child: ElevatedButton(
                      onPressed: _showZodiacDialog, 
                      child: const Text("Find Zodiac")
                      ),
                  ),
                  Expanded(
                    child: ElevatedButton(
                      onPressed: _clearData, 
                      child: const Text("Clear")
                      ),
                  ),
                ],
              )


          ],
        ),
      ),
    );
  }
}