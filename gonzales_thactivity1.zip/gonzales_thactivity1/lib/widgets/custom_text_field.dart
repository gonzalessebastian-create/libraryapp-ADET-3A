import 'package:flutter/material.dart';

class CustomTextField extends StatelessWidget {
  final TextEditingController controller;
  final TextInputType textInputType;
  final String label;
  final IconData icon;



  const CustomTextField({
  super.key,
  required this.controller,
  required this.label,
  required this.icon, 
  required this.textInputType,


  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: TextField(
        controller: controller,
        keyboardType: textInputType,
        decoration: InputDecoration(
          labelText: label,
          prefixIcon: Icon(icon),
          prefixIconColor: Theme.of(context).colorScheme.primary,
          border: const OutlineInputBorder(),
        ),
      ),
    );
  }
}